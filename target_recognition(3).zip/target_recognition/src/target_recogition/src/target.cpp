#include <iostream>
#include "opencv2/opencv.hpp"
#include <vector>

int main()
{
    cv::Mat ken = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3, 3));
    cv::Mat ken2 = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(5, 5));
    std::string path = "/home/x/visionlib/vision.mp4";
    cv::VideoCapture cap(path);
    if (!cap.isOpened())
    {
        std::cout << "NO FIND" << std::endl;
        return -1;
    }
    cv::namedWindow("video", cv::WINDOW_FREERATIO);
    cv::Mat src, thr, gray, dst, mor, dil;
    double threshold1 = 3;
    double threshold2 = 9;
    cv::Mat edges;
    while (1)
    {

        cap >> src;
        if (src.empty())
        {
            std::cout << "NO FIND SRC" << std::endl;
            return -1;
        }

        cv::cvtColor(src, gray, cv::COLOR_BGR2GRAY);
        // cv::adaptiveThreshold(gray, thr, 255, cv::ADAPTIVE_THRESH_MEAN_C, cv::THRESH_BINARY, 3, 0);
        cv::threshold(gray, thr, 150, 255, cv::THRESH_BINARY);

        cv::morphologyEx(thr, mor, cv::MORPH_OPEN, ken, cv::Point(-1, -1));
        cv::dilate(mor, dil, ken2, cv::Point(-1, -1));
        cv::Canny(dil, edges, threshold1, threshold2);
        std::vector<std::vector<cv::Point>> contour;
        cv::findContours(edges, contour, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        dst = src.clone();
        cv::Point2f vertex[4];

        std::vector<cv::RotatedRect> Rects;

        for (int i = 0; i < contour.size(); ++i)
        {
            cv::RotatedRect minRect = cv::minAreaRect(cv::Mat(contour[i]));
            minRect.points(vertex);
            if (minRect.size.width > minRect.size.height)
            {
                minRect.angle += 90;
                float t = minRect.size.width;
                minRect.size.width = minRect.size.height;
                minRect.size.height = t;
            }
            if (minRect.size.height > minRect.size.width * 1.5)
            {
                Rects.push_back(minRect);
            }
            for (int l = 0; l < 4; l++)
            {
                cv::line(dst, vertex[l], vertex[(l + 1) % 4], cv::Scalar(0, 0, 225), 3, cv::LINE_8, 0);
            }
        }

        cv::RotatedRect a, b;
        int area[2];
        std::vector<std::vector<int>> reliability;
        for (int i = 0; i < Rects.size(); i++)
        {
            for (int j = i + 1; j < Rects.size(); j++)
            {
                int cout = 0;
                a = Rects[i];
                b = Rects[j];
                if (a.angle == b.angle)
                {
                    cout = cout + 10;
                }
                else if (abs(a.angle - b.angle) < 5)
                {
                    cout = cout + 8;
                }
                else if (abs(a.angle - b.angle) < 10)
                {
                    cout = cout + 6;
                }
                else if (abs(a.angle - b.angle) < 30)
                {
                    cout = cout + 4;
                }
                else if (abs(a.angle - b.angle) < 60)
                {
                    cout = cout + 2;
                }
                else if (abs(a.angle - b.angle) < 90)
                {
                    cout = cout + 1;
                }
                else
                {
                    break;
                }
                cv::Point2f axy[4];
                cv::Point2f bxy[4];
                a.points(axy);
                b.points(bxy);

                area[0] = a.size.width * a.size.height;
                area[1] = b.size.width * b.size.height;

                if (area[0] == area[1])
                {
                    cout = cout + 10;
                }
                else if (std::min(area[0], area[1]) * 1.5 > std::max(area[0], area[1]))
                {
                    cout = cout + 6;
                }
                else if (std::min(area[0], area[1]) * 2 > std::max(area[0], area[1]))
                {
                    cout = cout + 4;
                }
                else if (std::min(area[0], area[1]) * 3 > std::max(area[0], area[1]))
                {
                    cout = cout + 2;
                }
                else if (std::min(area[0], area[1]) * 4 > std::max(area[0], area[1]))
                {
                    cout = cout + 1;
                }
                else
                {
                    break;
                }

                if (std::abs(a.center.y - b.center.y) < 1)
                {
                    cout = cout + 16;
                }
                else if (std::abs(a.center.y - b.center.y) < 3)
                {
                    cout = cout + 12;
                }
                else if (std::abs(a.center.y - b.center.y) < 5)
                {
                    cout = cout + 8;
                }
                else if (std::abs(a.center.y - b.center.y) < 7)
                {
                    cout = cout + 4;
                }
                else if (std::abs(a.center.y - b.center.y) < 11)
                {
                    cout = cout + 2;
                }
                else if (std::abs(a.center.y - b.center.y) < 15)
                {
                    cout = cout + 1;
                }
                else
                {
                    break;
                }

                double updown = std::abs((axy[1].y + axy[2].y) / 2 - (bxy[1].y + bxy[2].y) / 2);

                if (updown < 3)
                {
                    cout = cout + 20;
                }
                else if (updown < 5)
                {
                    cout = cout + 16;
                }
                else if (updown < 7)
                {
                    cout = cout + 12;
                }
                else if (updown < 9)
                {
                    cout = cout + 8;
                }
                else if (updown < 20)
                {
                    cout = cout + 4;
                }
                else
                {
                    break;
                }

                if (std::abs(a.center.x - b.center.x) < 100)
                {
                    cout = cout + 16;
                }
                else if (std::abs(a.center.x - b.center.x) < 150)
                {
                    cout = cout + 14;
                }
                else if (std::abs(a.center.x - b.center.x) < 180)
                {
                    cout = cout + 6;
                }
                else if (std::abs(a.center.x - b.center.x) < 250)
                {
                    cout = cout + 4;
                }
                else if (std::abs(a.center.x - b.center.x) < 1000)
                {
                    cout = cout + 2;
                }
                else if (std::abs(a.center.x - b.center.x) < 2000)
                {
                    cout = cout + 1;
                }
                else
                {
                    break;
                }

                std::vector<int> temp = {i, j, cout};
                reliability.push_back(temp);
            }
        }

        if (reliability.empty())
        {
        }
        else
        {
            int max_level = 0;
            int x = 0, y = 0;
            for (int i = 0; i < reliability.size(); i++)
            {
                if (reliability[i][2] > max_level)
                {
                    max_level = reliability[i][2];
                    x = reliability[i][0];
                    y = reliability[i][1];
                }
            }
            cv::Point2f arect[4];
            cv::Point2f brect[4];
            Rects[x].points(arect);
            Rects[y].points(brect);

            a = Rects[x];
            b = Rects[y];
            double ang = std::abs(a.angle - b.angle);
            cv::Point a1 = (arect[1] + arect[2]) / 2;
            cv::Point a2 = (arect[0] + arect[3]) / 2;
            cv::Point b1 = (brect[1] + brect[2]) / 2;
            cv::Point b2 = (brect[0] + brect[3]) / 2;

            if (ang < 90 && std::abs(a1.y - a2.y) > 1 && std::abs(a.center.y - b.center.y) < 15)
            {
                cv::line(dst, a1, b2, cv::Scalar(0, 255, 0), 5);
                cv::line(dst, a2, b1, cv::Scalar(0, 255, 0), 5);
            }
        }

        // cv::drawContours(dst, contour, -1, cv::Scalar(0, 0, 255), 2);

        cv::imshow("video", dst);

        if (cv::waitKey(1) == 27)
        {
            break;
        }
    }
    cap.release();
    cv::destroyAllWindows();
    return 0;
}